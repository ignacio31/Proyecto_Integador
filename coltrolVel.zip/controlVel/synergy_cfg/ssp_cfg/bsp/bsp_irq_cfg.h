/* generated configuration header file - do not edit */
#ifndef BSP_IRQ_CFG_H_
#define BSP_IRQ_CFG_H_
#endif /* BSP_IRQ_CFG_H_ */
