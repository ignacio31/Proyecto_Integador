/* HAL-only entry function */
#include "hal_data.h"
#include <math.h>
#define C_FILTER_ORDER (uint16_t)128
uint16_t u16ADC_FilteredData;
uint16_t u16ADC_Data;
float SETPOINT;     //RPM adjust
uint32_t counts;  //
uint32_t intRPM;    //integer part of RPM
uint32_t counter;
uint32_t tempo2;
const double factor=3.1635e-7;
const float A=7.5;
float AF;
float RPM;  //motor current speed

uint32_t PWM=75000;
float max=100000;   //max PWM value
float min=0;        //min PWM value
uint32_t uDutyCycle=25000;

float error;
float a=72.758;
float b=32.099;
float c=41.229;
float iT,iT0;
float dT;
float error0=0;
float uT=0; //output  PID
uint32_t u8DutyCycle=25000;
int32_t delay_us;
ioport_level_t level = IOPORT_LEVEL_HIGH;


void hal_entry(void)
{
    const bsp_delay_units_t bsp_delay_units =BSP_DELAY_UNITS_MICROSECONDS;
    uint32_t delay;
    /* ********************************INPUT ADC to read SETPOINT ************************************/
    g_adc0.p_api->open(g_adc0.p_ctrl, g_adc0.p_cfg);
    g_adc0.p_api->scanCfg(g_adc0.p_ctrl, g_adc0.p_channel_cfg);
    g_adc0.p_api->scanStart(g_adc0.p_ctrl);

    /* ************************OUTPUT PWM Timer ******************************************************/
   g_timer0.p_api->open (g_timer0.p_ctrl, g_timer0.p_cfg);
   g_timer0.p_api->start (g_timer0.p_ctrl);
    /* ************************ RPM pin port *********************************************************/
    //ioport_level_t p400_state=IOPORT_LEVEL_HIGH; // tolerant pin to  5 volts
    ioport_level_t p400_state; // tolerant pin to  5 volts
    AF=A/factor;
    /* **********************Function to measure RPM from the motor **********************************/
    void sensapulso(void)
        {   counter=0;
            g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_00,&p400_state);
            while(p400_state==1)
            {g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_00,&p400_state);}
            while(p400_state==0)
                {g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_00,&p400_state);}
            while(p400_state==1)
            {
             counter=counter+1;
             g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_00,&p400_state);
            }
            RPM=AF/(float)counter;
            return;
        }
    //************************************************************************************************/
        float PID_control(float error_t)
        {
            iT=b*error_t+iT0;        //integral term calculus
            dT=c*(error_t-error0);   //derivative term calculus
            uT=iT+a*error_t+dT;      //PID output calculus
            if(uT>max)               //adjust uT between max and min limits
            {uT=max;}
            if(uT<min)
            {uT=min;}
            iT0=iT;                  //update iT0
            error0=error_t;          //update error0
            return uT;
        }
    //************************************************************************************************/
        void toggle_pin()
        {
          if(level==IOPORT_LEVEL_HIGH)
              level=IOPORT_LEVEL_LOW;
          else
              level=IOPORT_LEVEL_HIGH;
          g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, level);
        }
     //***********************************************************************************************/

    while(1)
    {
        toggle_pin();
       // read set point
        g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_0, &u16ADC_Data);
        u16ADC_FilteredData = (u16ADC_Data + (C_FILTER_ORDER - 1)*u16ADC_FilteredData) / C_FILTER_ORDER;
        SETPOINT=(float)u16ADC_FilteredData*3300/4095;
       //measure RPM
        sensapulso();
        intRPM=RPM;
        error=SETPOINT-RPM;  // error calculus
        PWM=PID_control(error);
        //PWM=75000;
        g_timer0.p_api->dutyCycleSet(g_timer0.p_ctrl,PWM,TIMER_PWM_UNIT_PERCENT_X_1000,0);

        //display();

        if(RPM<406)
        {
         delay_us=0.0013*pow(RPM,3)- 1.7377*pow(RPM,2) + 875.12*RPM-116366;
        }
        if(RPM>406 && RPM<=1006)
        {
        delay_us=8e-05*pow(RPM,3)- 0.2168*pow(RPM,2) + 221.42*RPM-21933;
        }
        if(RPM>1006 && RPM<=2000)
        {
        delay_us=4e-06*pow(RPM,3)- 0.00252*pow(RPM,2) + 52.312*RPM+28.184;
        }
        if(RPM>2000 && RPM<=3300)
        {
        delay_us=5e-07*pow(RPM,3)- 0.0046*pow(RPM,2) + 16.496*RPM+48889;
        }

        R_BSP_SoftwareDelay(delay_us, bsp_delay_units);


    }
}
