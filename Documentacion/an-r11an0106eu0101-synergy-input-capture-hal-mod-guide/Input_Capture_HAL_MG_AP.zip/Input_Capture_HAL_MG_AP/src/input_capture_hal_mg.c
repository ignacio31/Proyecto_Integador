/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : input_capture_hal.c
* Description  : In the application project, the program uses a callback function to read the value. The value is captured periodically and
        is displayed on the IDE debug console using the common semi-hosting technique.
***********************************************************************************************************************/
#include <stdio.h>
#include "hal_data.h"
#include "input_capture_hal_mg.h"

#ifdef SEMI_HOSTING
#ifdef __GNUC__
extern void initialise_monitor_handles(void);
#endif
#endif

#define CHANNEL_ZERO (0U)
#define TIMER_SECOND (1000000000U)
#define TIMER_MILLISECOND (1000000U)
#define TIMER_MICROSECOND (1000U)
#define BIT_32 (0x100000000U)

static void error_trap(char *name, ssp_err_t err);

input_capture_info_t input_capture_info;

/*
 * This function prints out the error currently being trapped by the firmware
 */
void error_trap(char *name, ssp_err_t err)
{

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("%s: err = 0x%x",name, err);
    }
#endif

    while(1)
    {

    }
}

/**********************************************************************************************************************
 * input capture initialization
 *
 * Initialize GPT input capture and waveform output
 *
 **********************************************************************************************************************/
void input_capture_hal_module_guide_project(void)
{
    ssp_version_t input_capture_version;
    ssp_err_t err;

    #ifdef SEMI_HOSTING
    #ifdef __GNUC__
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
            initialise_monitor_handles();
    #endif
    #endif

    /* Initialize GPT Timer Driver */
    err = g_timer0.p_api->open(g_timer0.p_ctrl, g_timer0.p_cfg);
    if (SSP_SUCCESS != err)
    {
        error_trap("g_timer0.p_api->open", err);
    }

    /* Get the version of this API and code */
    err = g_input_capture.p_api->versionGet(&input_capture_version);
    if (SSP_SUCCESS != err)
    {
        error_trap("g_input_capture.p_api->versionGet", err);
    }

    /* Print API version and code version using semi-hosting function */
    #ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("API version is: %02d%02d\n",(int16_t)input_capture_version.api_version_major, (int16_t)input_capture_version.api_version_minor);
            printf("Code version is: %02d%02d\n",(int16_t)input_capture_version.code_version_major, (int16_t)input_capture_version.code_version_minor);
        }
    #endif

    /* Initialize Input Capture Driver */
    err = g_input_capture.p_api->open(g_input_capture.p_ctrl, g_input_capture.p_cfg);
    if (SSP_SUCCESS != err)
    {
        error_trap("g_input_capture.p_api->open", err);
    }

    /* Get the status (running or not) of the measurement counter */
    err = g_input_capture.p_api->infoGet(g_input_capture.p_ctrl, &input_capture_info);
    if (SSP_SUCCESS != err)
    {
        error_trap("g_input_capture.p_api->infoGet", err);
    }

    /* Print status of measurement counter using semi-hosting function*/
    #ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            if(INPUT_CAPTURE_STATUS_IDLE == input_capture_info.status)
            {
                printf("The input capture timer is idle.\n");
            }
            else
            {
                printf("A capture measurement is in progress.\n");
            }
            if(INPUT_CAPTURE_VARIANT_32_BIT == input_capture_info.variant)
            {
                printf("It is a 32-bit timer.\n\n");
            }
            else
            {
                printf("It is a 16-bit timer.\n\n");
            }
        }
    #endif

    while(1)
    {
    }
}

/**********************************************************************************************************************
 * callback function
 * Get the captured counter and overflows number when input capture interrupt occurs
 ***********************************************************************************************************************/
void input_capture_callback(input_capture_callback_args_t * p_args)
{
    static uint64_t capture_overflow = 0;
    static uint32_t capture_counter = 0;
    static uint32_t pclk_freq_hz = 0;
    static uint64_t time_captured = 0;

    if(CHANNEL_ZERO == p_args->channel)
    {
        switch(p_args->event)
        {
            case INPUT_CAPTURE_EVENT_MEASUREMENT:

                /* Get the value of the captured counter and overflows number */
                capture_counter = p_args->counter;

                /*
                * Currently there is a limitation for using API of lastCaptureGet, otherwise captured counter and overflows number can
                * be got from g_input_capture.p_api->lastCaptureGet. Please refer to the documentation for more information.
                */

                /* Get the frequency of PCLKD in Hz*/
                g_cgc_on_cgc.systemClockFreqGet(CGC_SYSTEM_CLOCKS_PCLKD, &pclk_freq_hz);

                /* Calculate time value of measurement (ns) */
                time_captured = (uint64_t)(((capture_overflow * BIT_32) + (uint64_t)capture_counter) * TIMER_SECOND / pclk_freq_hz);

                #ifdef SEMI_HOSTING
                    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
                    {
                        /* Debugger is connected */

                        /* Output current status and value captured */
                        printf("Input capture interrupt occurs.\n");
                        printf("The captured timer value from interrupt callback is: %ld\n", capture_counter);
                        printf("The overflows counter value from interrupt callback is: %ld\n", (uint32_t)capture_overflow);

                        /* Output time value of measurement */
                        if( time_captured < TIMER_MICROSECOND )
                        {
                            printf("Timer captured is: %ld ns\n", (uint32_t)((float)time_captured + 0.5F));
                        }
                        else if( (TIMER_MICROSECOND <= time_captured) && (time_captured < TIMER_MILLISECOND) )
                        {
                            printf("Timer captured is: %ld us\n", (uint32_t)(((float)time_captured / (float)TIMER_MICROSECOND) + 0.5F));
                        }
                        else if( (TIMER_MILLISECOND <= time_captured) && (time_captured < TIMER_SECOND) )
                        {
                            printf("Timer captured is: %ld ms\n", (uint32_t)(((float)time_captured / (float)TIMER_MILLISECOND) + 0.5F));
                        }
                        else
                        {
                            printf("Time captured is: %ld s\n", (uint32_t)(((float)time_captured / (float)TIMER_SECOND) + 0.5F));
                        }
                        if(INPUT_CAPTURE_STATUS_IDLE == input_capture_info.status)
                        {
                            printf("The input capture timer is idle.\n\n");
                        }
                        else
                        {
                            printf("A capture measurement is in progress.\n\n");
                        }
                    }
                #endif

                time_captured = 0;
                capture_overflow = 0;
                break;

            case INPUT_CAPTURE_EVENT_OVERFLOW:

                /* Overflows counter add one */
                capture_overflow++;

                /*
                * Current there is a limitation for using parameter of p_args->overflows, otherwise overflows number can be got from p_args->overflows. Please refer to the documentation.
                */

                #ifdef SEMI_HOSTING
                    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
                    {
                        /* Output current status*/
                        printf("Overflow interrupt occurs.\n");
                        if(INPUT_CAPTURE_STATUS_IDLE == input_capture_info.status)
                        {
                            printf("The input capture timer is idle.\n");
                        }
                        else
                        {
                            printf("A capture measurement is in progress.\n\n");
                        }
                    }
                #endif
                break;
            default:
                break;
        }
    }
}

